Camera Shy by Andy Moran, Winter 2020, COMP_ENG205
------------------------------------------------------------------------------------
To play the game, move the kid using the WASD keys for directional movement

Getting ran over by a car will result in Game Over

Grab the camera roll power up to take pictures
Press I to take a photo. Increase score by taking photos of the dog running
Taking a photo of something that isn't the dog will decrease score by 1
Getting multiple shots of the dog in a row will increase score by 2

Get a score of 10 or higher to win the game

Pause by pressing P


